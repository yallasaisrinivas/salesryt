package salesryt;

public class MonthlyCommission {

}
