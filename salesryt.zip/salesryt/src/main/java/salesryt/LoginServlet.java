package salesryt;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import salesryt.db.Database;
import salesryt.dbutil.AdminDatabaseUtil;
import salesryt.dbutil.Constants;
import salesryt.dbutil.DatabaseUtil;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username = request.getParameter("userId");
		String password = request.getParameter("password");

		
			if (validateAgent(username, password)) {
				HttpSession session = request.getSession();
				session.setAttribute("username", username);
				response.sendRedirect("AgentDashboard");
			}else if (validateAdmin(username, password)) {
				HttpSession session = request.getSession();
				session.setAttribute("username", username);
				response.sendRedirect("AdminDashboard");
			} else {
				request.setAttribute("wrong-credential", "Invalid username or password");
				response.sendRedirect("index.jsp?error=InvalidCredentials");
			}
	
	}
	
	
	private boolean validateAgent(String agentId, String password) {
		Database db = new DatabaseUtil();
		try (Connection conn = db.getConnection();
				PreparedStatement ps = conn
						.prepareStatement(Constants.ADMINLOGINQUERY)) {
			ps.setString(1, agentId);
			ps.setString(2, password);
			ps.setBoolean(3, false);

			try (ResultSet rs = ps.executeQuery()) {
				return rs.next();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	private boolean validateAdmin(String adminId, String password) {
		Database db = new AdminDatabaseUtil();
		try (Connection conn = db.getConnection();
				PreparedStatement ps = conn
						.prepareStatement(Constants.ADMINLOGINQUERY)) {
			ps.setString(1, adminId);
			ps.setString(2, password);
			ps.setBoolean(3, true);

			try (ResultSet rs = ps.executeQuery()) {
				return rs.next();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
