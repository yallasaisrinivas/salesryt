package salesryt.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;

import salesryt.Bean.Agent;
import salesryt.Bean.Sale;
import salesryt.db.AdminDatabase;

public class AdminDatabaseUtil implements AdminDatabase {
	private static final String URL = "jdbc:postgresql://localhost:5432/salesryt";
	private static final String USER = "postgres";
	private static final String PASSWORD = "admin";
	private static Connection con;

	public AdminDatabaseUtil() {
		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (Exception e) {
			System.out.println("Connection Error");
		}
	}
	public Connection getConnection() {
		return con;
	}

	public void addSales(Sale sale) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calculateCommision() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Sale> getAllSales(String agentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Agent> getAllAgents() {
		// TODO Auto-generated method stub
		return null;
	}

}
