package salesryt.dbutil;

public interface Constants {
	public static final String ADMINLOGINQUERY = "SELECT * FROM users WHERE userid = ? AND userpass = ? AND isadmin = ?";
	public static final String GETAGENTIDS = "SELECT userid FROM users";
	public static final String SALESQUERY = "SELECT * FROM Sales";
	public static final String AUTOINCREMENT = "SELECT max(saleid) as saleid from sales";
	public static final String ADDSALESQUERY = "INSERT INTO Sales (saleid, userid, saleType, saleAmount, refPhone, date) VALUES (?, ?, ?, ?, ?, ?)";
	public static final String GETALLSALESQUERY = "SELECT saleid, saletype, saleamount, refphone, date FROM Sales WHERE userid = ? AND date >= ?";
}
