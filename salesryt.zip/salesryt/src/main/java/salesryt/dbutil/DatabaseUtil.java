package salesryt.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;

import salesryt.Bean.Sale;
import salesryt.db.Database;

public class DatabaseUtil implements Database{
	private static final String URL = "jdbc:postgresql://localhost:5432/salesryt";
	private static final String USER = "postgres";
	private static final String PASSWORD = "admin";
	private static Connection con;

	public DatabaseUtil() {
		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (Exception e) {
			System.out.println("Connection Error");
		}
	}
	public Connection getConnection() {
		return con;
	}

	public void calculateCommision() {
		
	}
	public void addSales(Sale sale) {
		
	}
}
