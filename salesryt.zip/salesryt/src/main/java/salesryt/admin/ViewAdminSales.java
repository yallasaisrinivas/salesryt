package salesryt.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import salesryt.Bean.Sale;
import salesryt.db.Database;
import salesryt.dbutil.DatabaseUtil;

@WebServlet("/AdminSales")
public class ViewAdminSales extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Database db = new DatabaseUtil();
		List<Sale> salesList = new ArrayList<>();

		try {
			Connection conn = db.getConnection();
			PreparedStatement preparedStatement = conn.prepareStatement("select * from sales");
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Sale sale = new Sale();
				sale.setId(rs.getInt("saleid"));
				sale.setAgentUsername(rs.getString("userid"));
				sale.setSaleType(rs.getString("saleType"));
				sale.setAmount(rs.getDouble("saleAmount"));
				sale.setRefPhoneNumber(rs.getString("refphone"));
				sale.setDate(rs.getDate("date"));
				salesList.add(sale);
			}

			rs.close();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		request.setAttribute("salesList", salesList);
		request.getRequestDispatcher("view-admin-sales.jsp").forward(request, response);
	}

}
