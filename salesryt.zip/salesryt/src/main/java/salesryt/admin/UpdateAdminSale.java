package salesryt.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import salesryt.Bean.Sale;
import salesryt.db.Database;
import salesryt.dbutil.DatabaseUtil;

@WebServlet("/AdminUpdateSale")
public class UpdateAdminSale extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("saleId"));
		
		Database db = new DatabaseUtil();
		List<Sale> salesList = new ArrayList<>();

		try {
			Connection conn = db.getConnection();
			PreparedStatement preparedStatement = conn.prepareStatement("select * from sales where saleid = ?");
			preparedStatement.setInt(1, id);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Sale sale = new Sale();
				sale.setId(rs.getInt("saleid"));
				sale.setAgentUsername(rs.getString("userid"));
				sale.setSaleType(rs.getString("saleType"));
				sale.setAmount(rs.getDouble("saleAmount"));
				sale.setRefPhoneNumber(rs.getString("refphone"));
				sale.setDate(rs.getDate("date"));
				salesList.add(sale);
			}

			rs.close();
			preparedStatement.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		request.setAttribute("salesList", salesList);
		request.getRequestDispatcher("update-admin-sale.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int sid = Integer.parseInt(request.getParameter("id"));
	 	Database db = new DatabaseUtil();
        String agentId = request.getParameter("agentId");
        String saleType = request.getParameter("saleType");
        double saleAmount = Double.parseDouble(request.getParameter("saleAmount"));
        String referencePhoneNumber = request.getParameter("referencePhoneNumber");
        Date date = null;

        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            date = dateFormat.parse(request.getParameter("date"));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // Insert the new sale into the database
        try {
            Connection conn = db.getConnection();
            PreparedStatement preparedStatement = conn.prepareStatement("update sales set userid=?, saletype=?, saleamount=?, refphone=?, date=? where saleid=?");            
            preparedStatement.setString(1, agentId);
            preparedStatement.setString(2, saleType);
            preparedStatement.setDouble(3, saleAmount);
            preparedStatement.setString(4, referencePhoneNumber);
            preparedStatement.setDate(5, new java.sql.Date(date.getTime()));
            preparedStatement.setInt(6, sid);
            int update = preparedStatement.executeUpdate();
            
            if(update>0) {
            	request.getSession().setAttribute("saleUpdate", "udate");
            	response.sendRedirect("AdminSales");
            }
            preparedStatement.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}

}
