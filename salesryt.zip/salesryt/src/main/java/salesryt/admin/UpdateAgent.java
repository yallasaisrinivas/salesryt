package salesryt.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import salesryt.Bean.Agent;
import salesryt.db.Database;
import salesryt.dbutil.DatabaseUtil;

@WebServlet("/AgentUpdate")
public class UpdateAgent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	//Fetching previous agent data into update form
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("agentId");
		
		Database db = new DatabaseUtil();
		List<Agent> agentList = new ArrayList<>();

		try {
			Connection conn = db.getConnection();
			PreparedStatement preparedStatement = conn.prepareStatement("select userid, userpass from users where userid = ?");
			preparedStatement.setString(1, id);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Agent ag = new Agent();
				ag.setAgentId(rs.getString("userid"));
				ag.setAgentPass(rs.getString("userpass"));
				agentList.add(ag);
			}

			rs.close();
			preparedStatement.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		request.setAttribute("agentList", agentList);
		request.getRequestDispatcher("update-agent.jsp").forward(request, response);
	}
	
	// Updating agent data
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 	Database db = new DatabaseUtil();
	        String id = request.getParameter("id");
	        String agentId = request.getParameter("agentId");
	        String agentPass = request.getParameter("agentPass");
	        System.out.println(agentId);
	        // Insert the new sale into the database
	        try {
	            Connection conn = db.getConnection();
	            PreparedStatement preparedStatement = conn.prepareStatement("update users set userid=?, userpass=? where userid=?");            
	            preparedStatement.setString(1, agentId);
	            preparedStatement.setString(2, agentPass);
	            preparedStatement.setString(3, id);
	            int update = preparedStatement.executeUpdate();
	            
	            if(update>0) {
	            	request.getSession().setAttribute("agentUpdate", "update");
	            	response.sendRedirect("AddAgents");
	            }
	            preparedStatement.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	}

}
