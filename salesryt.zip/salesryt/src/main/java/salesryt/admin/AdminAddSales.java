package salesryt.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import salesryt.db.Database;
import salesryt.dbutil.Constants;
import salesryt.dbutil.DatabaseUtil;

@WebServlet("/SaleAddAdmin")
public class AdminAddSales extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 	Database db = new DatabaseUtil();
	        String agentId = request.getParameter("agentId");
	        String saleType = request.getParameter("saleType");
	        double saleAmount = Double.parseDouble(request.getParameter("saleAmount"));
	        String referencePhoneNumber = request.getParameter("referencePhoneNumber");
	        Date date = null;

	        try {
	            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	            date = dateFormat.parse(request.getParameter("date"));
	        } catch (ParseException e) {
	            e.printStackTrace();
	        }

	        // Insert the new sale into the database
	        try {
	            Connection conn = db.getConnection();
	            int count = 0;
	            String autoIncrement = Constants.AUTOINCREMENT;
	            PreparedStatement statement = conn.prepareStatement(autoIncrement);
	            ResultSet resultSet = statement.executeQuery();
	            while(resultSet.next()) {
	            	count = resultSet.getInt("saleid");
	            }
	            
	            String insertQuery = Constants.ADDSALESQUERY;
	            PreparedStatement preparedStatement = conn.prepareStatement(insertQuery);
	            preparedStatement.setInt(1, ++count);
	            preparedStatement.setString(2, agentId);
	            preparedStatement.setString(3, saleType);
	            preparedStatement.setDouble(4, saleAmount);
	            preparedStatement.setString(5, referencePhoneNumber);
	            preparedStatement.setDate(6, new java.sql.Date(date.getTime()));
	            int update = preparedStatement.executeUpdate();
	            if(update>0) {
	            	request.getSession().setAttribute("saleAdded", "added");
	            }
	            preparedStatement.close();
	            conn.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        // Redirect to the ViewSalesServlet to display the updated sales list
	        response.sendRedirect("AdminSales");
	}

}
