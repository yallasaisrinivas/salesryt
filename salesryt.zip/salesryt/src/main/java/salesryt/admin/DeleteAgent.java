package salesryt.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import salesryt.db.Database;
import salesryt.dbutil.DatabaseUtil;

@WebServlet("/AgentDelete")
public class DeleteAgent extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    Database db = new DatabaseUtil();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String id = request.getParameter("agentId");
		Connection connection = db.getConnection();
		try {
			PreparedStatement statement = connection.prepareStatement("delete from users where userid = ?");
			statement.setString(1, id);
			int update = statement.executeUpdate();
			if(update>0) {
				System.out.println("Agent deleted successfully");
				request.getSession().setAttribute("deleteSuccess", "success");
				response.sendRedirect("AddAgents");
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

}
