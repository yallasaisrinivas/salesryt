package salesryt.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import salesryt.Bean.Agent;
import salesryt.db.Database;
import salesryt.dbutil.DatabaseUtil;

@WebServlet("/AddAgents")
public class AddAgent extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Database db = new DatabaseUtil();
	
	// adding agent to the database
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String agentId = request.getParameter("agentId");
		String agentPass = request.getParameter("agentPass");
		try {
			Connection conn = db.getConnection();
            
            PreparedStatement prepareStatement = conn.prepareStatement("insert into users values(?, ?, ?)");
            prepareStatement.setString(1, agentId);
            prepareStatement.setString(2, agentPass);
            prepareStatement.setBoolean(3, false);
            
            int update = prepareStatement.executeUpdate();
            if(update>0) {
            	System.out.println("Agent added successfully");
            	response.sendRedirect("AddAgents");
            }
            
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	// Fetching all agent data in table
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		List<Agent> agentList = new ArrayList<>();
		try {
			Connection connection = db.getConnection();
			PreparedStatement statement = connection.prepareStatement("select * from users where isadmin = ?");
			statement.setBoolean(1, false);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Agent ag = new Agent();
				ag.setAgentId(resultSet.getString("userid"));
				ag.setAgentPass(resultSet.getString("userpass"));
				agentList.add(ag);
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		request.setAttribute("agentList", agentList);
		request.getRequestDispatcher("add-agent.jsp").forward(request, response);
		
	}

}
