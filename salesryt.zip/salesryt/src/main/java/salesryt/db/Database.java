package salesryt.db;

import java.sql.Connection;

import salesryt.Bean.Sale;

public interface Database {

	Connection getConnection();
	void addSales(Sale sale);
	void calculateCommision();
}
