package salesryt.db;

import java.sql.Connection;
import java.util.List;

import salesryt.Bean.Agent;
import salesryt.Bean.Sale;

public interface AdminDatabase extends Database {

	Connection getConnection();
	void addSales(Sale sale);
	void calculateCommision();
	List<Sale> getAllSales(String agentId);
	List<Agent> getAllAgents();
}
