package salesryt.Bean;

public class Admin {
	
	private String adminId;
	private String adminPass;
	
	public Admin(String adminId, String adminPass) {
		this.adminId = adminId;
		this.adminPass = adminPass;
	}
	
	public String getAdminId() {
		return adminId;
	}
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}
	public String getAdminPass() {
		return adminPass;
	}
	public void setAdminPass(String adminPass) {
		this.adminPass = adminPass;
	}

}
