package salesryt.Bean;

import java.util.Date;

public class Sale {
	
	private int id;
	private String agentUsername;
	private String saleType;
	private double amount;
	private String refPhoneNumber;
	private Date date;
	

	public Sale(int id, String agentUsername, String saleType, double amount, String refPhoneNumber, Date date) {
		this.id = id;
		this.agentUsername = agentUsername;
		this.saleType = saleType;
		this.refPhoneNumber = refPhoneNumber;
		this.amount = amount;
		this.date = date;
	}

	public Sale() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAgentUsername() {
		return agentUsername;
	}

	public void setAgentUsername(String agentUsername) {
		this.agentUsername = agentUsername;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getSaleType() {
		return saleType;
	}

	public void setSaleType(String saleType) {
		this.saleType = saleType;
	}

	public String getRefPhoneNumber() {
		return refPhoneNumber;
	}

	public void setRefPhoneNumber(String refPhoneNumber) {
		this.refPhoneNumber = refPhoneNumber;
	}

}
