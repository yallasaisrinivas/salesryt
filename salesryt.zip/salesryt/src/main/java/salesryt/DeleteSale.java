package salesryt;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import salesryt.db.Database;
import salesryt.dbutil.DatabaseUtil;

@WebServlet("/DeleteSaleServlet")
public class DeleteSale extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	Database db = new DatabaseUtil();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		int id = Integer.parseInt(request.getParameter("saleId"));
		Connection connection = db.getConnection();
		try {
			PreparedStatement statement = connection.prepareStatement("delete from sales where saleid = ?");
			statement.setInt(1, id);
			int update = statement.executeUpdate();
			if(update>0) {
				System.out.println("Sale deleted successfully");
				request.getSession().setAttribute("deleteSuccess", "success");
				response.sendRedirect("ViewSales");
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
}
