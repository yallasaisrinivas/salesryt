package salesryt;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import salesryt.Bean.Sale;
import salesryt.db.Database;
import salesryt.dbutil.DatabaseUtil;

@WebServlet("/DownloadSaleData")
public class DownloadSaleDataInExcel extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    // Set the content type and file name
//	    response.setContentType("application/vnd.ms-excel");
	    response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
	    response.setHeader("Content-Disposition", "attachment; filename=Sale-Data.xls");

	    // Get the PrintWriter object to write the response
	    PrintWriter out = response.getWriter();
	    Database db = new DatabaseUtil();
	    List<Sale> salesList = new ArrayList<>();

	    HttpSession session = request.getSession();
	    String agentId = null;
	    String isAdmin = null;
	    
	    try {
	        agentId = session.getAttribute("username").toString();
	    } catch (Exception e) {
	        System.out.println(e);
	    }
	    
	    try {
	    	Connection conn = db.getConnection();
	        PreparedStatement statement = conn.prepareStatement("select isadmin from users where userid =?");
	        statement.setString(1, agentId);
	        ResultSet resultSet = statement.executeQuery();
	        while(resultSet.next()) {
	        	isAdmin = resultSet.getString("isadmin");
	        }
	       
		} catch (Exception e) {
			System.out.println(e);
		}
	    System.out.println(isAdmin);
	    try {
	        Connection conn = db.getConnection();
	        if(isAdmin.equals("f")) {
	        	PreparedStatement preparedStatement = conn.prepareStatement("select * from sales where userId = ?");
	        	preparedStatement.setString(1, agentId);
		        ResultSet rs = preparedStatement.executeQuery();
		        
		        while (rs.next()) {
		            Sale sale = new Sale();
		            sale.setId(rs.getInt("saleid"));
		            sale.setAgentUsername(rs.getString("userid"));
		            sale.setSaleType(rs.getString("saleType"));
		            sale.setAmount(rs.getDouble("saleAmount"));
		            sale.setRefPhoneNumber(rs.getString("refphone"));
		            sale.setDate(rs.getDate("date"));
		            salesList.add(sale);
		        }

		        rs.close();
		        preparedStatement.close();
	        }else {
	        	PreparedStatement preparedStatement = conn.prepareStatement("select * from sales");
		        ResultSet rs = preparedStatement.executeQuery();
		        
		        while (rs.next()) {
		            Sale sale = new Sale();
		            sale.setId(rs.getInt("saleid"));
		            sale.setAgentUsername(rs.getString("userid"));
		            sale.setSaleType(rs.getString("saleType"));
		            sale.setAmount(rs.getDouble("saleAmount"));
		            sale.setRefPhoneNumber(rs.getString("refphone"));
		            sale.setDate(rs.getDate("date"));
		            salesList.add(sale);
		        }

		        rs.close();
		        preparedStatement.close();
	        }
	        

	        
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    // Write the Excel data
	    out.println("S.No.\tSaleId\tAgent Id\tSale Type\tSale Amount\tRef Phone No.\tDate");
	    int sno =1;
	    for (Sale s : salesList) {
	    	out.print(sno + "\t");
	        out.print(s.getId() + "\t");
	        out.print(s.getAgentUsername() + "\t");
	        out.print(s.getSaleType() + "\t");
	        out.print(s.getAmount() + "\t");
	        out.print(s.getRefPhoneNumber() + "\t");
	        out.print(s.getDate() + "\t");
	        out.println(); // Move to the next line for the next record
	        sno++;
	    }

	    // Close the PrintWriter
	    out.close();
	}


}
